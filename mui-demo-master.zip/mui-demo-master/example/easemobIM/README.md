### 使用说明：

需要在环信注册账号，并且将后台的appkey填到easemob.im.config.js下的appkey，demo基于环信webim sdk，实现文字、图片收发。

demo相关教程：https://segmentfault.com/a/1190000005729743