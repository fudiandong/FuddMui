### 说明

演示例子基于[cropperjs](https://github.com/fengyuanchen/cropperjs)及5+ API实现，原生js，无需依赖于jquery，实现头像裁剪并存为本地图片。

对于wap站下可以参考官方demo：
https://fengyuanchen.github.io/photo-editor/